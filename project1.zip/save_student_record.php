<?php
$nam=$_GET["stud_name"];
$coll=$_GET["stud_college"];
$eid=$_GET["stud_email"];
$rol=$_GET["stud_roll"];
$bran=$_GET["branch"];
$se=$_GET["sex"];
$deg=$_GET["course"];

//$nam2=isset($_GET["stud_name"])?1:0;
//$coll2=isset($_GET["stud_college"])?1:0;
//$eid2=isset($_GET["stud_email"])?1:0;

$bran2=isset($_GET["branch"])?1:0;
$se2=isset($_GET["sex"])?1:0;
$deg2=isset($_GET["course"])?1:0;


$con=mysql_connect("localhost","root","kumar");
$db=mysql_select_db("harsh",$con);
if($nam!=null && $coll!=null && $eid!=null && $rol!=null && $bran2==1 && $se2==1 && $deg2==1 )
{$rs=mysql_query("insert into stud_reg values('$nam','$coll','$eid','$rol','$bran','$se','$deg')");}
else
 { echo("<h1>some fields are empty</h1>\n");}

 if($rs==true)
 {
 echo("<h1>Successfully saved record</h1>");
 }
 else
 {
 echo("<h1>Record not saved.\n It may have already registered roll no or you have left some fields empty...</h1>");
 }
 mysql_close($con);
 ?>

