
			<?php
			    $nm=$_REQUEST["nm"];
				$con=mysql_connect("localhost","root","kumar");
				mysql_select_db("harsh",$con);
				//$qry="select * from stud_reg t1 join logintable t2 on t1.roll_no=t2.user_id where name like '$nm%'";
				//$qry="select t1.name,t2.user_id,t1.email,t1.branch,t2.password from stud_reg t1 join logintable t2 on t1.roll_no=t2.user_id where name like '$nm%'";
				$qry="select * from stud_reg left join logintable  on stud_reg.roll_no=logintable.user_id and name like '$nm%'";
				$rs=mysql_query($qry);
				if(mysql_num_rows($rs)>0)
					{
					?>

				       	<div style="background-color:pink; width:240px;float:left;border:0.5px solid black;">NAME</DIV>
				       	<div style="background-color:pink; width:320px;float:left;border:0.5px solid black;">COLLEGE</DIV>
						<div style="background-color:pink; width:280px;float:left;border:0.5px solid black;">EMAIL</DIV>
						<div style="background-color:pink; width:110px;float:left;border:0.5px solid black;">ROLL</DIV>
						<div style="background-color:pink; width:80px;float:left;border:0.5px solid black;">BRANCH</DIV>
						<div style="background-color:pink; width:50px;float:left;border:0.5px solid black;">SEX</DIV>
						<div style="background-color:pink; width:62px;float:left;border:0.5px solid black;">DEGREE</DIV>
						<div style="background-color:pink; width:110px;float:left;border:0.5px solid black;">User_id</DIV>
						<div style="background-color:pink; width:68px;float:left;border:0.5px solid black;">psd</DIV>





<?php
while($row=mysql_fetch_array($rs))
						{
                        echo("<div style='width:240px;float:left;border:0.5px solid black;'>$row[0]</DIV>");
						echo("<div style='width:320px;float:left;border:0.5px solid black;'>$row[1]</DIV>");
						echo("<div style='width:280px;float:left;border:0.5px solid black;'>$row[2]</DIV>");
						echo("<div style='width:110px;float:left;border:0.5px solid black;'>$row[3]</DIV>");
						echo("<div style='width:80px;float:left;border:0.5px solid black;'>$row[4]</DIV>");
						echo("<div style='width:50px;float:left;border:0.5px solid black;'>$row[5]</DIV>");
						echo("<div style='width:62px;float:left;border:0.5px solid black;'>$row[6]</DIV>");
						echo("<div style='width:110px;float:left;border:0.5px solid black;'>$row[7]</DIV>");
						echo("<div style='width:68px;float:left;border:0.5px solid black;'>$row[8]</DIV>");




						}
						}
										mysql_close($con);

			?>