<?php
$target = "upload/";
$target = $target . $_FILES['uploaded']['name'] ;
if(move_uploaded_file($_FILES['uploaded']['tmp_name'],$target))


echo("<div style=\"width:300px; height:230px; margin-top:50px;background-color:rgba(0,0,0,0.5);border-radius:15px;\"><H1>Downloading the File</h1><a href='$target'>Download File</a></div>");

?>
