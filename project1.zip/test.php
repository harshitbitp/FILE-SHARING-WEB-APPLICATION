<?php
	$nm=$_REQUEST["nm"];
	$con=mysql_connect("localhost","root","kumar");
	mysql_select_db("harsh",$con);
	$rs=mysql_query("select * from stud_reg where name like '$nm%'");
	if(mysql_num_rows($rs)>0)
		{
        echo("<div style='background-color:pink; width:240px;float:left;border:0.5px solid black;'>NAME</DIV>");
	    echo("<div style='background-color:pink; width:440px;float:left;border:0.5px solid black;'>COLLEGE</DIV>");
		echo("<div style='background-color:pink; width:340px;float:left;border:0.5px solid black;'>EMAIL</DIV>");
		echo("<div style='background-color:pink; width:80px;float:left;border:0.5px solid black;'>BRANCH</DIV>");
		echo("<div style='background-color:pink; width:80px;float:left;border:0.5px solid black;'>SEX</DIV>");
		echo("<div style='background-color:pink; width:80px;float:left;border:0.5px solid black;'>DEGREE</DIV>");

		while($row=mysql_fetch_array($rs))
			{
                echo("<div style='background-color:pink; width:240px;float:left;border:0.5px solid black;'>$row[0]</DIV>");
				echo("<div style='background-color:pink; width:440px;float:left;border:0.5px solid black;'>$row[1]</DIV>");
				echo("<div style='background-color:pink; width:340px;float:left;border:0.5px solid black;'>$row[2]</DIV>");
				echo("<div style='background-color:pink; width:80px;float:left;border:0.5px solid black;'>$row[3]</DIV>");
				echo("<div style='background-color:pink; width:80px;float:left;border:0.5px solid black;'>$row[4]</DIV>");
				echo("<div style='background-color:pink; width:80px;float:left;border:0.5px solid black;'>$row[5]</DIV>");

			}

		}
	mysql_close($con);
?>

