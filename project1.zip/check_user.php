<?php
	$unm=$_POST["txt_user_nm"];
	$pwd=$_POST["txt_password"];
	$con=mysql_connect("localhost","root","kumar");
	mysql_select_db("harsh",$con);
	$qry="select * from logintable where user_id='$unm' and password='$pwd'";
	$rs=mysql_query($qry);
	if(mysql_num_rows($rs)>0)
		{
		session_start();
		$_SESSION["uid"]=$unm;
		echo("<script>alert('Successfully Login. '); window.location='stud_download.php';</script>");
		}
	else
		{
		echo("<script>alert('Invalid User name or Password'); window.location='index.php';</script>");
		}
	mysql_close($con);
?>