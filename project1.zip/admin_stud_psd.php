<form action="admin_stud_psd_db.php" method="post">
<center>
<div style="width:200px;height:300px">
<div style="width:150px;float:left;">enter user-id</div>
<div style="width:50px;float:left"><input type='text' name='txt_id' /></div>

<div style="width:200px;float:left"> &nbsp;</div>


<div style="width:150px;float:left">enter password</div>
<div style="width:50px;float:left"><input type='password' name='txt_psd' /></div>
<input type="submit" value="submit"/>
</center>
</form>