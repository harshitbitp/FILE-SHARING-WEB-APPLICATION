<div style='background-color:#cc9999;width:250px;height:200px;float:left;'><center><h2><b>CSE</b></h2></center>

<form enctype="multipart/form-data" action="studentpage.php" method="post">
	 Please choose a file: <input name="uploaded" type="file" />
<br />	<input type="submit" value="Upload" />
<br/>
<a href='download_list.php'>Download Files</a>
</form>
</div>
<div style="width:50px;height:500px;float:left;"> </div>
<div style='background-color:#99CC99;width:250px;height:200px;float:left;'><center><h2><b>ECE</b></h2></center>

<form enctype="multipart/form-data" action="studentpage2.php" method="post">
	 Please choose a file: <input name="uploaded" type="file" />
<br />	<input type="submit" value="Upload" />
<br/>
<a href='download_list.php'>Download Files</a>
</form>
</div>

<div style="width:50px;height:500px;float:left;"> </div>
<div style='background-color:#99CC99;width:250px;height:200px;float:left;'><center><h2><b>ME</b></h2></center>

<form enctype="multipart/form-data" action="studentpage3.php" method="post">
	 Please choose a file: <input name="uploaded" type="file" />
<br />	<input type="submit" value="Upload" />
<br/>
<a href='download_list.php'>Download Files</a>
</form>
</div>


<div style="width:50px;height:500px;float:left;"> </div>
<div style='background-color:#99CC99;width:250px;height:200px;float:left;'><center><h2><b>CE</b></h2></center>

<form enctype="multipart/form-data" action="studentpage4.php" method="post">
	 Please choose a file: <input name="uploaded" type="file" />
<br />	<input type="submit" value="Upload" />
<br/>
<a href='download_list.php'>Download Files</a>
</form>
</div>


