Type Name : <input type="text" id="txt_nm" onkeyup="fun1()" /><br/><hr/>
<div id="div1">
	<h1>Ranjit Kumar</h1>
</div>

<script language="javascript" type="text/javascript">
	function fun1()
		{
		if(window.XMLHttpRequest)
			{
			obj1=new XMLHttpRequest();
			obj1.onreadystatechange=fun2;
			}
		var t1=document.getElementById("txt_nm").value;
		obj1.open("GET","test.php?nm="+t1,true);
		obj1.send();
		}
	function fun2()
		{
		if(obj1.readyState==4)
			{
			document.getElementById("div1").innerHTML=obj1.responseText;
			}
		}
</script>
