<body style="background-color:#cccc99;">
<center><h1>welcome to Download page</h1></center>
<div style='width:100%; float:left'><a href='logout.php' style='float:right'>Logout</a></div>
<div style='background-color:#cc9999;width:250px;height:500px;float:left;'><center><h2><b>CSE</b></h2></center>
<?php
	session_start();
	if(isset($_SESSION["uid"]))
		{
		}
	else
		{
		echo("<script>window.location='login.html'</script>");
		}
	$files=glob('upload\*.{jpg,pdf,png}',GLOB_BRACE);
	//print_r($files)
	foreach($files as $file)
		{
		echo("<a href='$file'>Download $file</a><br/>");
	}
?>
</div>
<div style="width:50px;height:500px;float:left;"> </div>
<div style="background-color:#99cc99;width:250px;height:500px;float:left;"><center><h2><b>ECE</b></h2></center>
<?php
	$files=glob('upload2\*.{jpg,jpeg,pdf,png}',GLOB_BRACE);
	//print_r($files)
	foreach($files as $file)
		{
		echo("<a href='$file'>Download $file</a><br/>");
	}
?>
</div>
<div style="width:50px;height:500px;float:left;"> </div>
<div style="background-color:#99ccff;width:250px;height:500px;float:left;"><center><h2><b>ME</b></h2></center>
<?php
	$files=glob('upload3\*.{jpg,pdf,png}',GLOB_BRACE);
	//print_r($files)
	foreach($files as $file)
		{
		echo("<a href='$file'>Download $file</a><br/>");
	}
?>

</div>
<div style="width:50px;height:500px;float:left;"> </div>
<div style="background-color:#999900;width:250px;height:500px;float:left;"><center><h2><b>CE</b></h2></center>
<?php
	$files=glob('upload4\*.{jpg,pdf,png}',GLOB_BRACE);
	//print_r($files)
	foreach($files as $file)
		{
		echo("<a href='$file'>Download $file</a><br/>");
	}
?>

</div>
</body>

