<?php
	$files=glob('upload2\*.{jpg,jpeg,pdf,png}',GLOB_BRACE);
	//print_r($files)
	foreach($files as $file)
		{
		echo("<a href='$file'>Download $file</a><br/>");
		}
?>