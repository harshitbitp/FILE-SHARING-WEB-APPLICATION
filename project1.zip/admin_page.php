<body style="background-color:#cccc99">
<center><h1>WELCOME ADMIN</H1>

<form action="admin_stud_psd_db.php" method="post">
<center>
<div style="width:320px;height:128px;background-color:#CC9900"></BR>
<div style="width:170px;float:left;"><B>CREATE USER_ID</B></div>
<div style="width:50px;float:left"><input type='text' name='txt_id' STYLE="WIDTH:130PX;" /></div>

<div style="width:200px;float:left"> &nbsp;</div>


<div style="width:170px;float:left"><B>CREATE PASSWORD</B></div>
<div style="width:50px;float:left"><input type='password' name='txt_psd' STYLE="WIDTH:130PX; /></div>
<div style="width:200px;float:left"> &nbsp;</div>

<div style="width:300px;FLOAT:LEFT;">
<input type="submit" value="submit"/></DIV>
</DIV>


</center>
</form>

Type Name : <input type="text" id="txt_nm" onkeyup="fun1()" /><br/><hr/>
<div id="div1">
	<h1> &nbsp;</h1>
</div>

<script language="javascript" type="text/javascript">
	function fun1()
		{
		if(window.XMLHttpRequest)
			{
			obj1=new XMLHttpRequest();
			obj1.onreadystatechange=fun2;
			}
		var t1=document.getElementById("txt_nm").value;
		obj1.open("GET","show_stud_record.php?nm="+t1,true);
		obj1.send();
		}
	function fun2()
		{
		if(obj1.readyState==4)
			{
			document.getElementById("div1").innerHTML=obj1.responseText;
			}
		}
</script>

</body>